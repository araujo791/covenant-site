"""Renderiza personagens articulados, letras e legendas a partir da faixa original."""
from pathlib import Path
import math,json,subprocess
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
from scipy.io import wavfile
ROOT=Path(__file__).resolve().parent
W,H,FPS,DURATION=1280,720,24,60
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def font(n):return ImageFont.truetype(FONT,n)
F={n:font(n) for n in [18,20,22,26,30,32,36,46,58,64]}
INK='#53416d';PINK='#e66c9c';TEAL='#248b91'
cues=json.loads((ROOT/'assets/cues.json').read_text())
rate,voice=wavfile.read(ROOT/'assets/voz.wav');voice=voice.astype(float)/32768
sheet=Image.open(ROOT/'assets/personagens.png').convert('RGBA')
# Crops include original, separate generated alpha mattes.
BOXES=[(0,165,443,892),(443,229,784,893),(786,303,1200,893),(1201,473,1536,892)]
chars=[sheet.crop(b) for b in BOXES]
MOUTHS=[(222,273,42,14),(172,354,27,11),(206,222,33,13),(174,194,22,9)]
EYES=[[(145,212,32,35),(292,212,32,35)],[(104,305,29,30),(227,305,29,30)],[(140,161,30,30),(270,161,30,30)],[(118,163,26,28),(241,163,26,28)]]

def center(d,text,y,ft,fill=INK,x=640):
 d.text((x,y),text,font=ft,fill=fill,anchor='mt')

def backdrop():
 im=Image.new('RGB',(W,H));a=np.zeros((H,W,3),dtype=np.uint8)
 top=np.array([238,244,255]);bottom=np.array([255,236,241])
 for y in range(H):a[y,:,:]=top*(1-y/H)+bottom*y/H
 im=Image.fromarray(a);d=ImageDraw.Draw(im)
 d.ellipse((1020,40,1130,150),fill='#fff6bc')
 # Soft hills and stylized flowering trees, kept behind the stage.
 d.ellipse((-220,360,800,1050),fill='#c2e6d5');d.ellipse((650,365,1580,1050),fill='#b8dfcc')
 for x,y,s in [(-35,220,1.0),(1210,245,.9),(80,220,.55),(1135,250,.45)]:
  d.rounded_rectangle((x-12*s,y,x+12*s,y+290*s),radius=9,fill='#bda0ad')
  for ox,oy,r in [(-55,0,75),(30,-35,85),(80,15,75),(-5,40,100)]:
   d.ellipse((x+(ox-r)*s,y+(oy-r)*s,x+(ox+r)*s,y+(oy+r)*s),fill='#f6cfdf')
 d.ellipse((-80,525,1360,1050),fill='#e3f2d4')
 d.ellipse((40,545,1240,710),fill='#d2e8c3')
 for k in range(43):
  x=(k*179+17)%W;y=560+(k*83)%150
  for j in range(5):
   angle=j*2*math.pi/5;xx=x+5*math.cos(angle);yy=y+5*math.sin(angle)
   d.ellipse((xx-4,yy-4,xx+4,yy+4),fill=['#f4b5cc','#fff4bd','#d0bee9'][k%3])
  d.ellipse((x-2,y-2,x+2,y+2),fill='#e4b358')
 return im
BG=backdrop()

def draw_char(index,t,volume,active):
 im=chars[index].copy();d=ImageDraw.Draw(im)
 mx,my,mw,mh=MOUTHS[index]
 # Open shapes cover only the closed smile; all coordinates remain sprite-local.
 if active and volume>.012:
  openness=min(1,volume*9)
  if index==3:
   d.ellipse((mx-mw*.8,my-2,mx+mw*.8,my+5+18*openness),fill='#814b30')
   d.arc((mx-mw,my-13,mx+mw,my+11),0,180,fill='#efad34',width=4)
  else:
   hh=8+mh*openness
   d.ellipse((mx-mw,my-4,mx+mw,my+hh*2),fill='#643040',outline='#a75466',width=2)
   d.ellipse((mx-mw*.62,my+hh,mx+mw*.62,my+hh*1.86),fill='#ee829c')
   d.rounded_rectangle((mx-mw*.66,my-3,mx+mw*.66,my+3),radius=2,fill='#fff5eb')
 # Blink briefly at staggered intervals. Tiny eyelids follow face palettes.
 blink=(t+index*.7)%4.1
 if blink<.11:
  color=['#f5b8a5','#f6ece7','#c98d51','#55b2d3'][index]
  for ex,ey,rx,ry in EYES[index]:
   d.ellipse((ex-rx-3,ey-ry-3,ex+rx+3,ey+ry+3),fill=color)
   d.arc((ex-rx,ey-12,ex+rx,ey+10),0,180,fill='#594252',width=4)
 # Wave the mascot's hands and the bird's wings around shoulder pivots.
 if index in [0,3]:
  regions=([(0,365,92,525),(342,365,443,525)] if index==0 else [(0,205,63,345),(278,205,335,345)])
  for side,box in enumerate(regions):
   piece=im.crop(box);im.paste((0,0,0,0),box)
   angle=(7 if side==0 else -7)*math.sin(t*math.pi*4+side)
   piece=piece.rotate(angle,resample=Image.Resampling.BICUBIC)
   im.alpha_composite(piece,(box[0],box[1]))
 return im

def frame(t):
 im=BG.copy().convert('RGBA');d=ImageDraw.Draw(im)
 # Drifting little clouds and musical notes.
 for k in range(4):
  x=int((k*430+t*8)%(W+240))-120;y=170+(k%2)*55
  d.ellipse((x,y,x+100,y+24),fill='#ffffff')
 d.text((42,28),'A TURMA DO H',font=F[26],fill=INK)
 d.text((1238,33),'CANTE • BRINQUE • APRENDA',font=F[18],fill=TEAL,anchor='rt')
 current=next((c for c in cues if c['start']<=t<c['end']),None)
 group=current['group'] if current else ('H' if t<2 else 'CH · LH · NH')
 label={'H':'Vamos fazer amizade?', 'CH':'C + H  →  CH','LH':'L + H  →  LH','NH':'N + H  →  NH'}.get(group,'CH   •   LH   •   NH')
 d.rounded_rectangle((325,81,955,166),radius=30,fill='#ffffff',outline='#e3c6e6',width=2)
 center(d,label,93,F[46] if group!='H' else F[36])
 examples={'H':'Duas letras podem formar um só som!','CH':'CHUVA   •   CHÁ','LH':'FOLHA   •   COELHINHO','NH':'NINHO   •   PASSARINHO'}
 center(d,examples.get(group,'Duas letras juntas, um som para aprender!'),179,F[22],TEAL)
 p=int(t*rate);seg=voice[p:min(p+int(rate*.035),len(voice))];rms=float(np.sqrt(np.mean(seg**2))) if len(seg) else 0
 beat=t*math.pi*4
 positions=[(535,596,390),(832,588,297),(220,590,286),(1060,555,190)]
 for idx,(cx,bottom,h) in enumerate(positions):
  active=current is not None
  bob=abs(math.sin(beat/2+idx*.4))*(9 if active else 3)
  d=ImageDraw.Draw(im);sw=[125,105,118,79][idx]
  d.ellipse((cx-sw,bottom-8,cx+sw,bottom+15),fill='#bdd4b4')
  sprite=draw_char(idx,t,rms,active)
  targetw=round(sprite.width*h/sprite.height)
  sprite=sprite.resize((targetw,h),Image.Resampling.LANCZOS)
  sprite=sprite.rotate(1.5*math.sin(beat/2+idx),resample=Image.Resampling.BICUBIC,expand=True)
  im.alpha_composite(sprite,(round(cx-sprite.width/2),round(bottom-sprite.height-bob)))
  # Notes pulse on the score, following the voice envelope.
  if active and rms>.025:
   d=ImageDraw.Draw(im);xx=cx+(-75 if idx%2==0 else 70);yy=bottom-h*.72-15*math.sin(beat+idx)
   d.text((xx,yy),'♪',font=F[36],fill=[PINK,TEAL,'#bc8a42','#6295cf'][idx])
 d=ImageDraw.Draw(im)
 # Karaoke word highlight, generated from the same timing as synthesized notes.
 d.rounded_rectangle((65,622,1215,702),radius=25,fill='#ffffff',outline='#e0ccdf',width=2)
 caption=current['caption'] if current else ('Venha cantar com a turma!' if t<2 else 'CH, LH e NH: aprendemos juntos!')
 words=caption.split();ft=F[32];widths=[d.textlength(w+' ',font=ft) for w in words];x=(W-sum(widths))/2
 active_word=-1
 if current:
  active_word=next((j for j,w in enumerate(current['words']) if w['start']<=t<w['end']),-1)
 for j,(word,width) in enumerate(zip(words,widths)):
  if j==active_word:d.rounded_rectangle((x-6,636,x+width-3,681),radius=11,fill='#ffe3a2')
  d.text((x,640),word,font=ft,fill=PINK if j==active_word else INK)
  x+=width
 d.rounded_rectangle((91,691,1189,695),radius=2,fill='#eee7f0')
 d.rounded_rectangle((91,691,91+1098*min(t/60,1),695),radius=2,fill='#af94c4')
 return im.convert('RGB')

def main():
 out=ROOT/'output';out.mkdir(exist_ok=True)
 cmd=['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r',str(FPS),'-i','-', '-i',str(ROOT/'assets/nova_musica.wav'),'-map','0:v','-map','1:a','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart','-t','60',str(out/'a_turma_do_h.mp4')]
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 try:
  for i in range(FPS*DURATION):
   proc.stdin.write(frame(i/FPS).tobytes())
   if i%(FPS*10)==0: print(f'Render: {i//FPS}/60s',flush=True)
 finally:proc.stdin.close()
 if proc.wait():raise RuntimeError('ffmpeg falhou')
 # Sidecar subtitles complement the burned-in karaoke captions.
 def stamp(t):
  ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
 (out/'legendas.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['caption']}" for i,c in enumerate(cues)),encoding='utf-8')

if __name__=='__main__':main()
