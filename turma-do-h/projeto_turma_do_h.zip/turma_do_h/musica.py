"""Canção original: síntese local de voz afinada com WORLD e arranjo procedural."""
from pathlib import Path
import ctypes as C, json, math
import numpy as np
from scipy.signal import resample_poly
import soundfile as sf
import pyworld as pw
import espeakng_loader as el

ROOT=Path(__file__).resolve().parent
SR=24000
DURATION=60
# Cada frase ocupa dois compassos, 120 bpm. Texto separado da pronúncia.
LINES=[
 ('O H chamou a turma','O agá chamou a turma','H'),
 ('No jardim para cantar','No jardim para cantar','H'),
 ('C com H faz chuva','Cê com agá faz chuva','CH'),
 ('E chá para esquentar','E chá para esquentar','CH'),
 ('L com H faz folha','Éle com agá faz folha','LH'),
 ('Coelhinho vem dançar','Coelhinho vem dançar','LH'),
 ('N com H faz ninho','Êne com agá faz ninho','NH'),
 ('Passarinho vai cantar','Passarinho vai cantar','NH'),
 ('Duas letras, um só som','Duas letras um só som','CH · LH · NH'),
 ('Vamos juntos aprender','Vamos juntos aprender','CH · LH · NH'),
 ('Chuva, folha e passarinho','Chuva folha e passarinho','CH · LH · NH'),
 ('Eu já sei, e sei dizer','Eu já sei e sei dizer','CH · LH · NH'),
 ('Com carinho e alegria','Com carinho e alegria','CH · LH · NH'),
 ('Novos sons, eu e você!','Novos sons eu e você','CH · LH · NH'),
]

def main():
 lib=el.load_library()
 lib.espeak_Initialize.argtypes=[C.c_int,C.c_int,C.c_char_p,C.c_int]
 native=lib.espeak_Initialize(2,0,el.get_data_path().encode(),0)
 lib.espeak_SetVoiceByName(b'pt-br')
 lib.espeak_SetParameter(1,155,0) # rate
 lib.espeak_SetParameter(3,62,0) # pitch
 lib.espeak_SetParameter(4,0,0) # intonation: WORLD provides melody
 chunks=[]
 @C.CFUNCTYPE(C.c_int,C.POINTER(C.c_short),C.c_int,C.c_void_p)
 def cb(ptr,n,events):
  if n: chunks.append(np.ctypeslib.as_array(ptr,shape=(n,)).copy())
  return 0
 lib.espeak_SetSynthCallback(cb)
 lib.espeak_Synth.argtypes=[C.c_void_p,C.c_size_t,C.c_uint,C.c_int,C.c_uint,C.c_uint,C.c_void_p,C.c_void_p]
 def say(txt):
  chunks.clear();b=txt.encode()+b'\0';buf=C.create_string_buffer(b)
  lib.espeak_Synth(buf,len(b),0,1,0,1,None,None);lib.espeak_Synchronize()
  x=np.concatenate(chunks).astype(float)/32768
  nz=np.flatnonzero(np.abs(x)>.008)
  return resample_poly(x[max(0,nz[0]-200):nz[-1]+500],SR,native)
 vocal=np.zeros(SR*DURATION); cues=[]
 melody=[[64,67,69,67,64,62,60],[64,65,67,69,67,64,62],[67,67,69,72,71,69,67],[65,64,62,64,62,60,60]]
 for i,(caption,spoken,group) in enumerate(LINES):
  words=spoken.split();start=2+i*4
  # Allocate time by vowel groups; leave a half beat to breathe.
  import re
  weights=np.array([max(1,len(re.findall(r'[aeiouáéíóúâêôãõ]+',w.lower()))) for w in words],float)
  durations=weights/weights.sum()*3.65
  cursor=start;events=[]
  for j,(word,dur) in enumerate(zip(words,durations)):
   x=say(word); x=np.ascontiguousarray(x,dtype=np.float64)
   f0,t=pw.harvest(x,SR,f0_floor=65,f0_ceil=650,frame_period=5)
   spec=pw.cheaptrick(x,f0,t,SR); ap=pw.d4c(x,f0,t,SR)
   n=max(8,round((dur-.025)/.005)); old=np.linspace(0,1,len(f0));new=np.linspace(0,1,n)
   # Resample spectral envelope in time, then impose an original tune.
   from scipy.interpolate import interp1d
   sp=np.ascontiguousarray(interp1d(old,spec,axis=0)(new));a=np.ascontiguousarray(interp1d(old,ap,axis=0)(new))
   voiced=np.interp(new,old,(f0>0).astype(float))>.35
   note=melody[i%4][min(j,6)]+(0 if i<8 else 2)
   hz=440*2**((note-69)/12)
   f=np.where(voiced,hz*(1+.009*np.sin(np.arange(n)*.005*2*np.pi*5)),0).astype(float)
   y=pw.synthesize(f,sp,a,SR,frame_period=5)
   y*=np.minimum(1,np.arange(len(y))/180)*np.minimum(1,np.arange(len(y))[::-1]/300)
   pos=round(cursor*SR);vocal[pos:pos+len(y)]+=y*.95
   events.append({'start':round(cursor,4),'end':round(cursor+dur,4),'spoken':word,'note':note})
   cursor+=dur
  cues.append({'start':start,'end':start+4,'caption':caption,'group':group,'words':events})
 print('Voz sintetizada',flush=True)
 # Original C major / A minor / F / G accompaniment.
 music=np.zeros_like(vocal); rng=np.random.default_rng(17)
 def add(time,duration,hz,amp,kind='bell'):
  n=int(duration*SR);t=np.arange(n)/SR
  if kind=='bell': y=(np.sin(2*np.pi*hz*t)+.28*np.sin(2*np.pi*hz*2*t)+.11*np.sin(2*np.pi*hz*3*t))*np.exp(-t*7)
  elif kind=='bass': y=(np.sin(2*np.pi*hz*t)+.18*np.sin(2*np.pi*hz*2*t))*np.exp(-t*4)
  elif kind=='kick': y=np.sin(2*np.pi*(55*t+6*(1-np.exp(-t*25))))*np.exp(-t*20)
  else: y=rng.normal(0,1,n)*np.exp(-t*65)
  y*=np.minimum(1,t*600);p=int(time*SR);end=min(len(music),p+n);music[p:end]+=y[:end-p]*amp
 chords=[(48,[60,64,67]),(45,[57,60,64]),(41,[57,60,65]),(43,[59,62,67])]
 for beat in range(120):
  tm=beat*.5;root,ch=chords[(beat//8)%4]
  add(tm,.44,440*2**((root-69)/12),.12,'bass')
  add(tm,.18,0,.09,'kick')
  for off in [0,.25]:add(tm+off,.09,0,.018,'shaker')
  for k in range(2):add(tm+k*.25,.55,440*2**((ch[(beat*2+k)%3]+12-69)/12),.047)
  if beat%2==1:add(tm,.1,0,.035,'shaker')
 # Short call-and-response glockenspiel in the introduction and last bar.
 for base in [0,58]:
  for j,note in enumerate([72,76,79,76,74,72]):add(base+j*.25,.45,440*2**((note-69)/12),.07)
 # Small room reflections, voice forward, no borrowed audio.
 voice=vocal.copy()
 for delay,gain in [(.075,.10),(.14,.06)]:
  d=int(SR*delay);voice[d:]+=vocal[:-d]*gain
 mono=voice+music
 stereo=np.stack([mono,music*.98+voice],axis=1)
 peak=np.max(np.abs(stereo));stereo*=.92/max(peak,.92)
 fade=np.minimum(1,np.arange(len(mono))/(SR*.2))*np.minimum(1,np.arange(len(mono))[::-1]/(SR*1.2))
 stereo*=fade[:,None]
 sf.write(ROOT/'assets/nova_musica.wav',stereo,SR,subtype='PCM_16')
 sf.write(ROOT/'assets/voz.wav',vocal,SR,subtype='PCM_16')
 (ROOT/'assets/cues.json').write_text(json.dumps(cues,ensure_ascii=False,indent=2))
 print('Música original criada: 60s, 120 bpm.',flush=True)

if __name__=='__main__':main()
