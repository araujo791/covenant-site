# A Turma do H — canção e animação originais

Entrega: `output/a_turma_do_h.mp4`, 1280×720, 24 fps, 60 segundos,
H.264 + AAC estéreo. Legendas de karaokê incorporadas e SRT separado.

## O que foi criado

Letra, melodia e acompanhamento novos, em português brasileiro. Arranjo
em 120 bpm, com instrumentos sintetizados: sinos, baixo e percussão.
A voz é uma síntese local eSpeak NG em português brasileiro, afinada e
temporizada com WORLD. **O timbre é eletrônico/robótico**, sem imitação
de pessoa real; não foi usado um serviço externo de canto neural.
O WAV contém canto sintético com notas fixadas pela composição, e não
o áudio da referência. Uma voz cantada natural e expressiva exigiria
uma nova gravação ou um serviço de canto disponível e autorizado.

A mascote foi recriada a partir da imagem fornecida, mantendo cabelo
ruivo, olhos grandes roxos e roupa rosa/lilás com botões azuis.
Os personagens foram gerados como elementos visuais RGBA.
O vídeo usa animação 2D de personagens recortados, com balanço,
pulinhos, mãos/asas articuladas, piscadas e bocas que respondem à voz.
Não se trata de animação 3D completa ou sincronização fonema a fonema.

Os tempos de cada palavra e suas notas estão em `assets/cues.json`.
O destaque das legendas usa esses mesmos tempos; a abertura das bocas
usa o RMS do canal vocal isolado em janelas de 35 ms.

## Reproduzir

Python 3.10+, ffmpeg no PATH e fontes DejaVu Sans. Para compilar
pyworld pode ser necessário GCC/G++ instalado.

```sh
python -m pip install -r requirements.txt
python animar.py
```

Os áudios e as marcações já estão incluídos. Para ressintetizar toda a
música antes de renderizar:

```sh
python musica.py
python animar.py
```

Em ambientes cujo compilador padrão não está disponível:
`CC=gcc CXX=g++ python -m pip install -r requirements.txt`.
Altere `FONT` em `animar.py` se DejaVu estiver em outro caminho.

## Integração com nova gravação

É possível substituir `assets/nova_musica.wav` por uma gravação
autorizada de 60 segundos. Substitua também `assets/voz.wav` pela voz
isolada, em WAV PCM 16 bits, e atualize os tempos em `assets/cues.json`
para manter a sincronização. Execute `python animar.py` novamente.
Os tempos dos WAVs atuais e de `cues.json` já estão sincronizados.

## Análise da referência

Referência fornecida: 57,333 s, vídeo vertical 720×1280 a 30 fps.
Uma análise de batidas estimou aproximadamente 86 bpm; trata-se de
estimativa automática, com variação nas posições das batidas.
Foram observadas quedas de energia entre frases, por exemplo perto
de 7,7–7,9 s e 11,5–11,6 s. A composição nova mantém frases curtas
e pausas para respirar, mas usa uma melodia e um arranjo independentes.
A referência não é uma entrada de `musica.py` ou de `animar.py` e não
foi incluída neste pacote de reprodução.

## Letra

O H chamou a turma / No jardim para cantar
C com H faz chuva / E chá para esquentar
L com H faz folha / Coelhinho vem dançar
N com H faz ninho / Passarinho vai cantar
Duas letras, um só som / Vamos juntos aprender
Chuva, folha e passarinho / Eu já sei, e sei dizer
Com carinho e alegria / Novos sons, eu e você!

As letras isoladas são cantadas como nomes: agá, cê, éle e êne.
O conteúdo ensina que as combinações apresentadas têm um só som;
não apresenta o H isolado como uma letra de som próprio.

## Proveniência

Imagem de referência da mascote: fornecida pelo usuário.
Nova arte dos personagens: ferramenta de geração de imagens.
Composição, letra, síntese musical e renderização: scripts deste projeto.
Dependências externas conservam suas respectivas licenças, incluindo
eSpeak NG (GPL), WORLD/pyworld (licenças dos projetos), Pillow, NumPy,
SciPy, libsndfile e ffmpeg. As bibliotecas não estão empacotadas aqui.
